<!DOCTYPE html>
<html>
<head>
<title>About CI View</title>
</head>

<body>
	<h1>About Codeigniter Views</h1>
</body>
</html>